<?php

namespace App\Repository;

use App\Entity\ProviderOrder;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Common\Persistence\ManagerRegistry;

/**
 * @method ProviderOrder|null find($id, $lockMode = null, $lockVersion = null)
 * @method ProviderOrder|null findOneBy(array $criteria, array $orderBy = null)
 * @method ProviderOrder[]    findAll()
 * @method ProviderOrder[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ProviderOrderRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ProviderOrder::class);
    }

    // /**
    //  * @return ProviderOrder[] Returns an array of ProviderOrder objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('p.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?ProviderOrder
    {
        return $this->createQueryBuilder('p')
            ->andWhere('p.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
