<?php
// src/Controller/LuckyController.php
namespace App\Controller\Admin;

use App\Entity\Echeance;
use App\Entity\Category;
use App\Form\CategoryType;
use App\Entity\CustomerCommande;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Http\Util\TargetPathTrait;

/**
 * @Route("/admin/echeances")
 */
class AdminEcheanceController extends AbstractController
{
    /**
     * @Route("/", name="echeances")
     * @IsGranted("ROLE_ADMIN")
     */
    public function index(ObjectManager $manager)
    {
        $categories = $manager->getRepository(Echeance::class)->findAll();
        return $this->render('Admin/Category/index.html.twig', [
          'current'    => 'products',
          'categories' => $categories
        ]);
    }

    /**
     * @Route("/add/{id}", name="echeance_add", requirements={"id"="\d+"})
     * @IsGranted("ROLE_ADMIN")
     * @param CustomerCommande $commande
     */
    public function add(Request $request, ObjectManager $manager, CustomerCommande $commande)
    {
      if($request->isMethod('post'))
      {
        $data = $request->request->all();
        $token  = $data['token'];
        // return new Response(var_dump($data));
        if($this->isCsrfTokenValid('token_dates_echeances', $token)){
          if(isset($data["dates"])){
            $dates = $data["dates"];
            foreach ($dates as $key => $value) {
              $montant = isset($data["montant"]) ? $data["montant"] : 0;
              $echeance = new Echeance();
              $echeance->setCommande($commande);
              $echeance->setDateEcheance(new \DateTime($value));
              $echeance->setCreatedBy($this->getUser());
              $echeance->setCreatedAt(new \DateTime());
              $manager->persist($category);
            }
          }
          try{
            $manager->flush();
            $this->addFlash('success', 'Enregistrement de la catégorie <strong>'.$category->getName().'</strong> réussie.');
          } 
          catch(\Exception $e){
            $this->addFlash('danger', $e->getMessage());
          } 
        }
      }
          
      return $this->render('Admin/Echeance/echeance-add.html.twig', [
        'current' => 'products',
        'commande' => $commande,
      ]);
    }
          
    /**
     * @Route("/edit/{id}", name="echeance_edit")
     * @IsGranted("ROLE_ADMIN")
     * @param Category $category
     */
    public function edit(Request $request, ObjectManager $manager, Category $category)
    {
      $form = $this->createForm(CategoryType::class, $category);
      $form->handleRequest($request);
      if($form->isSubmitted() && $form->isValid())
      {
        $category->setUpdatedAt(new \DateTime());
        $category->setUpdatedBy($this->getUser());
        try{
          $manager->flush();
          $this->addFlash('success', 'Mise à jour de la catégorie <strong>'.$category->getName().'</strong> réussie.');
        } 
        catch(\Exception $e){
          $this->addFlash('danger', $e->getMessage());
        } 
        return $this->redirectToRoute('category');
      }

      return $this->render('Admin/Category/category-edit.html.twig', [
        'current'  => 'products',
        'category' => $category,
        'form'     => $form->createView()
      ]);
    }
}
